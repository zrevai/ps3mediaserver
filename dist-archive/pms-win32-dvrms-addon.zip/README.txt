You just have to unzip the contents of this archive into the root folder of PS3 Media Server
The DVR-MS specific FFmpeg muxer will be automatically activated and choosed with .dvr-ms files