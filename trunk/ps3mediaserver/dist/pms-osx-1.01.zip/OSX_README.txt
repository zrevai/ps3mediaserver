Installation steps

- Open a console and cd to the directory you extracted the archive in (for instance 'cd Downloads/pms-osx-1.01/')
- Make sure that PMS.sh is executable by running 'chmod +x PMS.sh'
- Start the app by running './PMS.sh'

